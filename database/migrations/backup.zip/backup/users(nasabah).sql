-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 02 Bulan Mei 2020 pada 17.23
-- Versi server: 10.3.22-MariaDB-cll-lve
-- Versi PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kongkon1_banksampah`
--

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `kategori`, `name`, `username`, `email`, `telepon`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(11, 'Nasabah', 'Fadhil Jamaluddin', 'kingfadhiljamaluddin', 'fadhiljamaluddin28@gmail.com', '088218687083', '$2y$10$.m4qjW1OwcjOSM.KWPWOYO6aopQpf9AGWKXy4Q8W/Mh1nFZw4D9si', NULL, '2020-04-30 00:59:45', '2020-04-30 00:59:45'),
(12, 'Nasabah', 'Imey Indayanti Ensar', 'Imeyiensar', 'imyiensar@gmail.com', '+6288290485530', '$2y$10$Gz5FuRfFeSZxNatb.3obgO5xa724ZhplHJBDLyAKkXKlhCEXJuSz6', NULL, '2020-04-30 01:11:30', '2020-04-30 01:11:30'),
(13, 'Nasabah', 'Muhammad Sulthan Ali Adani', 'Sulthan ali', 'sulthanptnh@gmail.com', '081389704432', '$2y$10$zS1BJWZYDop1n0mr.P/meOHKM1y/eMkNDrjEG8zWhogBWXcKew3vO', NULL, '2020-04-30 01:22:48', '2020-04-30 01:22:48'),
(14, 'Nasabah', 'MUTHIA AZZAHRA', 'muthiaaz', 'azzahramuthia12@gmail.com', '087896572509', '$2y$10$wWSVLBTg0VqnX6pmttP8BOA4rfOJMkq/MRvrYWe4Rt6Lvu2nHn7mC', NULL, '2020-04-30 01:30:44', '2020-04-30 01:30:44'),
(15, 'Nasabah', 'Muhammad Akbar Rahib', 'Akbarrahib', 'barok.kingkong@gmail.com', '082135322762', '$2y$10$WGZTFMeF67xmsjAvmCoWe.uLhXUaJ.MQVZZGwzm0UNofLB0IFswSG', NULL, '2020-04-30 01:38:18', '2020-04-30 01:38:18'),
(16, 'Nasabah', 'Teuku Moch. Alif Maulana Risaf', 'Teuku Alif', 'teukualif17@gmail.com', '081389165110', '$2y$10$uW2M5VeMaTL69qmFWYRqCOjSKXM.8H7BleGSKiBpeFjPtVjD4qaSW', NULL, '2020-04-30 01:45:00', '2020-04-30 01:45:00'),
(17, 'Nasabah', 'Bagus Muhammad Abid', 'Bagus Abid', 'bagusibnu08@gmail.com', '081287142815', '$2y$10$Bq3pH1ZAJ5w8kwBOMmtuK.rKbobKVO5FPESjzjQvp.f58KJkcA0xq', NULL, '2020-04-30 02:11:42', '2020-04-30 02:11:42'),
(18, 'Nasabah', 'Lindhu Dwi P', 'Prakoso', 'Zalzalah0818@gmail.com', '081217229663', '$2y$10$vhaWQ65EwvOYq4Gmi9eQsOujDWm4r8rZrNF06/IgQX1BlMWWuDuP2', NULL, '2020-04-30 02:50:27', '2020-04-30 02:50:27'),
(19, 'Nasabah', 'Muhammad Harist', 'Harist', 'harist.syahirul@gmail.com', '087879625768', '$2y$10$o0K6VKFMQ0URY5eeMx7Er.r/WtdAG.gBZ7K1uop7V.Omm21DBZvu.', NULL, '2020-04-30 03:07:59', '2020-04-30 03:07:59'),
(20, 'Nasabah', 'Alam Suprobo Suryowati', 'Alam Suprobo Suryowati', 'alamsuprobosuryowati01@gmail.com', '081226217152', '$2y$10$uzq2aNMPHTIzVTTy8OjmbOwuQN4IC1Xs8z9gjl5u5tO3UtW4DD.5m', NULL, '2020-04-30 03:30:01', '2020-04-30 03:30:01'),
(21, 'Nasabah', 'andi priti sukma', 'andipriti', 'pritisukma@gmail.com', '082293422120', '$2y$10$TLORlIna8nTcOkdnl3X72e1feOqGqwQhu.89iqyLN37eCSnXxX8TO', NULL, '2020-04-30 03:30:55', '2020-04-30 03:30:55'),
(22, 'Nasabah', 'Muhammad Nurfauzi Gustiana', 'Fauzi', 'Ffauzi597@gmail.com', '081280562433', '$2y$10$1UtUcYAflG0wodc8whmMhO.r1Wq3.u28k9VFKzACPkjzq32FxBW.2', NULL, '2020-04-30 03:31:06', '2020-04-30 03:31:06'),
(23, 'Nasabah', 'Muhammad Isymam', 'isymam', 'isymammuhammad@gmail.com', 'Muhammad Isymam', '$2y$10$fMpRLxFa2IHhF0FpAYqdg.mHxgpCsToNGweF3S1uc5rpdH61PduN.', NULL, '2020-04-30 03:37:55', '2020-04-30 03:37:55'),
(24, 'Nasabah', 'yoswandimarhaba', 'Yoswandi', 'yoswandimarhaba@gmail.com', '082293290664', '$2y$10$B3agwzTkTuF3aCREvAip.eu0wTJj8opTSDk6aHwqZzaQbMBkBF3RS', NULL, '2020-04-30 03:39:32', '2020-04-30 03:39:32'),
(25, 'Nasabah', 'Reemar', 'Reemar', 'jionmyo66@gmail.com', '082193267313', '$2y$10$uKHzO5vo9XmzuRvKltaQIecw7kpT7Dv9FKcRqx.z8wPdPtAjPhXSy', NULL, '2020-04-30 03:52:33', '2020-04-30 03:52:33'),
(26, 'Nasabah', 'Hidayat Chandra', 'hidayat', 'hidayatchandra08@gmail.com', '082296605921', '$2y$10$PXcl/kE/f6T8D6.SHYsIO.x79NSNe8sXNfgxasb3Ox7Pr7C3M724W', 'BppbxRhOsBEJWYWb73jhCdwGA3tbcDHsbZRORug5MhQ1LWNQZwZaheLKg7fe', '2020-04-30 03:53:32', '2020-04-30 03:53:32'),
(28, 'Nasabah', 'Jusman', 'code', 'tolakyjusman@gmail.com', '082393698553', '$2y$10$Bb1J5f7twSp8/9ZfwOqLKOgdC3KqHhysG2bq64GmKpi.X3bAdqgiK', 'MyB2cdVJrZ4qYNPsvbgFjicDq2IqkFHtcMGCRSBDtTLorQ01Ukne8tL7uorX', '2020-04-30 04:09:36', '2020-04-30 04:09:36'),
(29, 'Nasabah', 'Siti Duniah', 'Sitiduniah', 'bagush422@gmail.com', '081806006515', '$2y$10$Jh/34YyWO1efxQ9c52/LVOd5wwLVsA6vap4d2BYt7L2h.ZR6KW1mG', NULL, '2020-04-30 04:26:53', '2020-04-30 04:26:53'),
(30, 'Nasabah', 'Rahmawaty Khoerunnisa', 'Rahmakh', 'Zoerhapsody96@gmail.com', '089622849364', '$2y$10$7w8Ax3lnn2lt9sQIKMYtFuOCs.YRVrn960.6jlDJT8DIMrGm83Z8m', NULL, '2020-04-30 06:25:34', '2020-04-30 06:25:34'),
(31, 'Nasabah', 'David', 'David', 'davidlubis789@gmail.com', '082248883878', '$2y$10$IYu2k.r7F9wSehkaHRVpu.hFefT8cGgkIRPO8mGGrhXXB6CzvSFZO', 'vRdulqEnKpbIpl3IZg3etmkOaHFenqfEmJq5BNY5puvCS30p6dGv7Um1K67Q', '2020-04-30 06:48:21', '2020-04-30 06:48:21'),
(32, 'Nasabah', 'Siti Sarifah', 'Riffah', 'sarifahnasyita86@gmail.com', '0895800418762', '$2y$10$TKuhE0rRONqZSUPzQcSh6.4br0jjud42MXdIwSjfR9i68ZktiTlye', NULL, '2020-04-30 06:53:32', '2020-04-30 06:53:32'),
(33, 'Nasabah', 'Zulfi Nindyatami', 'Zulfi Nindyatami', 'zulfinindya@gmail.com', '089648382770', '$2y$10$3qtoYLXxlmbshD3fBPiLtO4CxgNajjqRZwmqicZzGQO2J3qR9isUC', NULL, '2020-04-30 06:56:29', '2020-04-30 06:56:29'),
(34, 'Nasabah', 'Tajuddin Abdillah', 'tajuddin@ung.ac.id', 'tajuddin@ung.ac.id', '08124466687', '$2y$10$mVuGoVvOa9.Xce/VgZPReeKLCFf4pPrD8r8TYgaj3Z2g2gmP.9aBG', NULL, '2020-04-30 07:04:11', '2020-04-30 07:04:11'),
(35, 'Nasabah', 'Devani Kusnandi Puteri', 'Devanikusnandip', 'devani.kp20@gmail.com', '081297106226', '$2y$10$lS.Mq.C/te5cjd.g3Hi6teRUk10E9N2REC64kmrKJbJ2ix6lbjxvq', NULL, '2020-04-30 07:14:55', '2020-04-30 07:14:55'),
(36, 'Nasabah', 'Hermanto Lakoro', 'hermamdev', 'hermantolakoro@gmail.com', '085398104825', '$2y$10$fvV3CGTirEupzyxrfsoBwuRWMiYu7MVUEmVMmkyWNQ8SVEFLpqJpu', 'oCfjpRrAR5AUHWgFWY8gpxg67LnL6tKDbHD3oNBLv37jEUEK3XTyKLbnTe5Y', '2020-04-30 08:00:37', '2020-04-30 08:00:37'),
(37, 'Nasabah', 'Regent Aprianto', 'Uciha saskeh', 'regenthusen3@gmail.com', '085289371178', '$2y$10$U8Y/fMbgjh70k8FVwj7ZWuUiMi9/M1y.KqIvUWLAmB00JfNs1r.xW', NULL, '2020-04-30 08:08:38', '2020-04-30 08:08:38'),
(38, 'Nasabah', 'Syafei Adnan', 'Syafeiadnan13', 'syafeiadnan13@gmail.com', '089626329298', '$2y$10$K75IKe6TBeab0AevsBgR/end/MPqXLfHLAcfuA6P9uyoarDxKR2bO', NULL, '2020-04-30 09:23:06', '2020-04-30 09:23:06'),
(39, 'Nasabah', 'Bambang Lihawa', 'Winner99', 'lihawabambang@gmail.com', '085399613968', '$2y$10$u.PNq3nGQXk9/mYQqyLDTe87m.OiYSV2andVT4glRFBz6pojMw6pS', NULL, '2020-04-30 09:41:28', '2020-04-30 09:41:28'),
(40, 'Nasabah', 'Sindi Kenora', 'Sindy Kenora', 'sindikenora06@gmail.com', '082289637569', '$2y$10$ogCIyUzP3psQukjjCBfFzOPWVLzR1/9pF6lBeH/PR7M4JuKWEPqWy', NULL, '2020-04-30 14:22:16', '2020-04-30 14:22:16'),
(41, 'Nasabah', 'Suherman', 'Suherman', 'suherman.psminggu@gmail.com', '087782353838', '$2y$10$iCgxsV3uHo.8v.vabptgWuLzybM9eSXGBCLTYTrBe8MuueHDvHp2.', 'vWvj3WnDoULsH0NQ0v3UfEIB0sL0Js0jjMFQC8jn750XVTn0K4NrLYOLYQRy', '2020-04-30 14:24:37', '2020-04-30 14:41:41'),
(42, 'Nasabah', 'Venia Eka Bestari', 'Veniaeka', 'veniaeka.b@gmail.com', '087771088058', '$2y$10$IVnjrX1YuXoXLAqNqQBX6OGOVyE5c1JKyH.MQXNl323GRIOXDcaqe', NULL, '2020-04-30 14:40:41', '2020-04-30 14:40:41'),
(43, 'Nasabah', 'Wapoga P', 'Wapoga P', 'wapogapurnama@gmail.com', '082113563992', '$2y$10$7r/Tiv1LO0rX7jJB.gKzo.HELoC84nG1DusVRgsJ3CCOdINZTirt6', NULL, '2020-04-30 16:15:23', '2020-04-30 16:15:23'),
(44, 'Nasabah', 'Muhammad Rizky Ramadhan', 'Rizkyriz', 'e919mrizkyr@gmail.com', '087700325517', '$2y$10$Joz/G4vuK/BqkGMcjMSGUOOE.qEvZZ3JPxGe4/Y9jsuy301OOmHpe', NULL, '2020-04-30 19:35:07', '2020-04-30 19:35:07'),
(45, 'Nasabah', 'Nunu ahmad', 'Nunu ahmad', 'nhuuahmad@gmail.com', '085342198098', '$2y$10$.p1Tj5G1qVh3gKEWeA23NOmPVajGx0o7kfwILPh3uDbS8WlsKXqSe', NULL, '2020-04-30 20:37:00', '2020-04-30 20:37:00'),
(46, 'Nasabah', 'Annisa zaidah', 'Annisa zay', 'Annisazay3007@gmail.com', '081212077255', '$2y$10$Fm4vC9awYOvuKJ0KnXD4Wux16Z7NSqqQldrGNp4V3Q6wl7j1kmjSm', 'ov0XSpQwwIwGhG4wi5y8on5yA6gsf2o0tW06KgnLiPUNpRGOe9ioslNWwLcZ', '2020-04-30 21:41:32', '2020-05-01 02:12:27'),
(47, 'Nasabah', 'Cindy Purnama', 'Cindy Purnama', 'cindypurnamaaa99@gmail.com', '081369357145', '$2y$10$uEowZGLuciFXHtgMDyzrueXr25Y7LRmXqSSbDurdX0jfmkpjUu2EW', NULL, '2020-04-30 22:11:18', '2020-04-30 22:11:18'),
(48, 'Nasabah', 'Yuni Avika Sari', 'Yuni Avika Sari', 'avikasari66@gmail.com', '087878174178', '$2y$10$70A5FMaVqiK/.f1Wgr1dKe2p4rDVYzkJ2vl7eHwAFvB3Xvmns/uZG', NULL, '2020-04-30 22:18:14', '2020-04-30 22:18:14'),
(49, 'Nasabah', 'Arip Mulyanto', 'aripmulyanto', 'arip.mulyanto2303@gmail.com', '085240850881', '$2y$10$jbkPGtXP56g5I4jRNRgkUeNL7YK95yoK3yRDKEDTs2D17iH9wwxM.', 'TbJY7Fu2bjxASTDBGfmldwmVK7TvPVpERiU5sfkh5u24QMhXbgpbWDCmZM6x', '2020-05-01 01:34:16', '2020-05-01 01:34:16'),
(53, 'Nasabah', 'Fadli', 'fadli', 'fadli@wilihandarwo.com', '081398609262', '$2y$10$4AmTkjFcxdQbISVeZnSp2.ROjBC0YavxKLFlKE8QHT0GqjrbFS4ta', NULL, '2020-05-01 02:05:27', '2020-05-01 02:05:27'),
(54, 'Nasabah', 'Rifqi', 'rifqi13', 'nurmandarifqi@gmail.com', '081316280752', '$2y$10$rEWPfShay3lZGtb6Rl51tOsYtbY.3I5GmYLzgkRylYayv6lAOh/9W', NULL, '2020-05-01 07:20:06', '2020-05-01 07:20:06'),
(55, 'Nasabah', 'Indah', 'Indah Lestari', 'lstrindah8@gmail.com', '087824894009', '$2y$10$NetmDKL8J6c4EY2mg7qM8.mbBb/BaSZ99hhUsjHN4iGuLOiLEw3gy', NULL, '2020-05-01 07:27:27', '2020-05-01 07:27:27'),
(56, 'Nasabah', 'dabi roup', 'droup', 'dabi476ok@gmail.com', '088210518160', '$2y$10$7vjx9jsUlZpJLImeSQAdJeb7PfbOOflzf9ESJoKapkUa0STeYI7oy', NULL, '2020-05-01 14:40:22', '2020-05-01 14:40:22'),
(57, 'Nasabah', 'Jovan', 'Jovan Erlando', 'jvnerlando@gmail.com', '081808414262', '$2y$10$r.BEPKTIq2UQ8ZkRPoXuR.MTXCVHGO5FCltDLxUq9HKD1zosSyxoq', NULL, '2020-05-01 18:54:02', '2020-05-01 18:54:02');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
