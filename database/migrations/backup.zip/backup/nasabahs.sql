-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 03 Bulan Mei 2020 pada 05.34
-- Versi server: 10.3.22-MariaDB-cll-lve
-- Versi PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kongkon1_banksampah`
--

--
-- Dumping data untuk tabel `nasabahs`
--

INSERT INTO `nasabahs` (`id`, `id_user`, `ktp`, `provinsi`, `alamat`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 11, '3213200604010002', 'Jawa Barat', 'Jl. Raya Cipeundeuy KM 25 RT 20 RW 06, Kec. Cipeundeuy, Kab. Subang', '2020-04-30 00:59:45', '2020-04-30 00:59:45', NULL),
(5, 12, '3214095209020001', 'Jawa Barat', 'Kp krajan rt 02/01 desa sumurugul kec. Wanayasa', '2020-04-30 01:11:30', '2020-04-30 01:11:30', NULL),
(6, 13, '3215155709940004', 'Jawa Barat', 'Dsn kamojing barat,rt/rw 11/05 desa kamojing,kec.cikampek,kab.karawang,prov.jawa barat,41373', '2020-04-30 01:22:48', '2020-04-30 01:22:48', NULL),
(7, 14, '3175036112010003', 'DKI Jakarta', 'Jl. Cipinang Muara 1', '2020-04-30 01:30:44', '2020-04-30 01:30:44', NULL),
(8, 15, '2171063009019003', 'Kepulauan Riau', 'Baloi Blok V, Kota Batam, Kep. Riau', '2020-04-30 01:38:18', '2020-04-30 01:38:18', NULL),
(9, 16, '3214011804010007', 'Jawa Barat', 'Bojong Kidul, Rt.19/05 No.12, Kec. Nagri Kidul, Kab. Purwakarta', '2020-04-30 01:45:00', '2020-04-30 01:45:00', NULL),
(10, 17, '3215132707020001', 'Jawa Barat', 'Perum mahkota blok DE 01 NO 03', '2020-04-30 02:11:42', '2020-04-30 02:11:42', NULL),
(11, 18, '3314022605010001', 'Jawa Tengah', 'Nadri', '2020-04-30 02:50:27', '2020-04-30 02:50:27', NULL),
(12, 19, '3205011805020003', 'Jawa Barat', 'Puri Melati blok A2, Purwakarta', '2020-04-30 03:07:59', '2020-04-30 03:07:59', NULL),
(13, 20, '3313155905010001', 'Jawa Tengah', 'Sewurejo 01/04, Mojogedang, Karanganyar', '2020-04-30 03:30:01', '2020-04-30 03:30:01', NULL),
(14, 21, '7571055010980002', 'Gorontalo', 'jl sultan botutihe no. 141 kel. padebuolo kec. kota timur', '2020-04-30 03:30:55', '2020-04-30 03:30:55', NULL),
(15, 22, '3214161508010002', 'Jawa Barat', 'Kp. krajan III, Desa Tanjungsari, kecamatan Pondoksalam, Kota Purwakarta', '2020-04-30 03:31:06', '2020-04-30 03:31:06', NULL),
(16, 23, '3325121311010001', 'Jawa Tengah', 'Jl. Walisinongko No.3 Terban Warungasem Batang', '2020-04-30 03:37:55', '2020-04-30 03:37:55', NULL),
(17, 24, '7501033112980001', 'Gorontalo', 'Desa huntu kec. Batudaa kab. Gorontalo', '2020-04-30 03:39:32', '2020-04-30 03:39:32', NULL),
(18, 25, '0102030405060', 'Gorontalo', 'Jalan Dua Susun\r\nKomp. SD 64 Kota timur', '2020-04-30 03:52:33', '2020-04-30 03:52:33', NULL),
(19, 26, '71246481290002', 'Gorontalo', 'Jl. H.B Jassin No.337', '2020-04-30 03:53:32', '2020-04-30 03:53:32', NULL),
(21, 28, '7571060805900001', 'Gorontalo', 'Jl. Kenangan 3', '2020-04-30 04:09:36', '2020-04-30 04:09:36', NULL),
(22, 29, '3174045605690006', 'DKI Jakarta', 'Jl. Pagu Jaten Rt.016/06 No.50E', '2020-04-30 04:26:54', '2020-04-30 04:26:54', NULL),
(23, 30, '322117860988', 'Jawa Barat', 'Jl.Bina jaya rt01/03', '2020-04-30 06:25:34', '2020-04-30 06:25:34', NULL),
(24, 31, '7203041905990002', 'Gorontalo', 'Jl.dimba', '2020-04-30 06:48:21', '2020-04-30 06:48:21', NULL),
(25, 32, '3305074806010001', 'Jawa Tengah', 'Prasutan, Ambal, Kebume', '2020-04-30 06:53:32', '2020-04-30 06:53:32', NULL),
(26, 33, '3214016005010006', 'Jawa Barat', 'Jl. Kapten Halim Kp. Gembong RT 44 RW 15 Kel. Sindangkasih Kec/Kab Purwakarta 41112', '2020-04-30 06:56:29', '2020-04-30 06:56:29', NULL),
(27, 34, '7501010812780001', 'Gorontalo', 'bulila telaga', '2020-04-30 07:04:11', '2020-04-30 07:04:11', NULL),
(28, 35, '3215136006010006', 'Jawa Barat', 'Perum Karang Mas indah blok b5 no 28 dawuan tengah cikampek', '2020-04-30 07:14:55', '2020-04-30 07:14:55', NULL),
(29, 36, '123456', 'Gorontalo', 'kec. limboto kab.gorontalo', '2020-04-30 08:00:37', '2020-04-30 08:00:37', NULL),
(30, 37, '7571062404980003', 'Gorontalo', 'Jl. Bali 3, Kelurahan Paguyaman Kecamatan Kota Tengah, Kota Gorontalo', '2020-04-30 08:08:38', '2020-04-30 08:08:38', NULL),
(31, 38, '38', 'Sumatera Barat', 'Kota Pariaman, Sumbar', '2020-04-30 09:23:06', '2020-04-30 09:23:06', NULL),
(32, 39, '39', 'Gorontalo', 'Tapa', '2020-04-30 09:41:28', '2020-04-30 09:41:28', NULL),
(33, 40, '1702184605010001', 'DKI Jakarta', 'Jl. Nakula Cimanggis Depok', '2020-04-30 14:22:16', '2020-04-30 14:22:16', NULL),
(34, 41, '3174042008620007', 'DKI Jakarta', 'Jl. Pagujaten Rt.016/06 No.50E', '2020-04-30 14:24:37', '2020-04-30 14:24:37', NULL),
(35, 42, '42', 'Jawa Tengah', 'Ds. Gondang rt 17/04 taman pemalang', '2020-04-30 14:40:41', '2020-04-30 14:40:41', NULL),
(36, 43, '43', 'Jawa Barat', 'Komp PKC blok B-10', '2020-04-30 16:15:23', '2020-04-30 16:15:23', NULL),
(37, 44, '3374080112010002', 'Jawa Tengah', 'Semarang', '2020-04-30 19:35:07', '2020-04-30 19:35:07', NULL),
(38, 45, '750102511970002', 'Gorontalo', 'Jln pemuda desa tinelo', '2020-04-30 20:37:00', '2020-04-30 20:37:00', NULL),
(39, 46, '46', 'Jawa Barat', 'Jomin estate, cikampek', '2020-04-30 21:41:32', '2020-05-01 02:29:28', NULL),
(40, 47, '-', 'DKI Jakarta', 'Jl. Kenanga IV Depok Jaya, Pancoran Mas', '2020-04-30 22:11:18', '2020-04-30 22:11:18', NULL),
(41, 48, '3328064606010004', 'DKI Jakarta', 'Jl. Swadaya II buntu no. 54H RT. 007/05', '2020-04-30 22:18:14', '2020-04-30 22:18:14', NULL),
(42, 49, '49', 'Gorontalo', 'Jl. Taman Hiburan 1, Kelurahan Wongkaditi Barat, Kecamatan Kota Timur, Kota Gorontalo', '2020-05-01 01:34:16', '2020-05-01 01:34:16', NULL),
(45, 53, '53', 'Jawa Tengah', 'Jl. Pucang', '2020-05-01 02:05:27', '2020-05-01 02:05:27', NULL),
(46, 54, '54', 'Jawa Barat', 'Jl. Raya Cikopo NO. 7', '2020-05-01 07:20:06', '2020-05-01 07:20:06', NULL),
(47, 55, '55', 'Jawa Barat', 'Jl. Kapten Halim Gg. Benteng Pasawahan', '2020-05-01 07:27:27', '2020-05-01 07:27:27', NULL),
(48, 56, '56', 'DKI Jakarta', 'jl.h.samali ujung II', '2020-05-01 14:40:22', '2020-05-01 14:40:22', NULL),
(49, 57, '321401290801004', 'Jawa Barat', 'Cipaisan rt23/06 Kec purwakarta', '2020-05-01 18:54:02', '2020-05-01 18:54:02', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
